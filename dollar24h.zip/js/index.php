<html>
<head>
    <meta charset="UTF-8" />
	<title>Dollar24h - Make Dollar Free</title>
	
    
    <link rel='stylesheet prefetch' href='http://fonts.googleapis.com/css?family=Open+Sans+Condensed:300'>
<link rel='stylesheet prefetch' href='http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css'>

        <link rel="stylesheet" href="css/style.css">

</head>
<body>
   <div class="loginform-open">
  <a href=""><i class="fa fa-list-alt fa-lg"></i> Đăng nhập hệ thống</a>
</div>
<center>
	<form action="home.php" method="get">
		<table>
			<tr>
				<td colspan="2"><h2>Bạn đã sẵn sàng nhận $ free?</h2></td>
			</tr>	
			
			
			
			<tr>
				<td>Email PayPal:</td>
				<td><input type="email" id="emailpaypal" name="emailpaypal"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="get" value="GetDollar!"></td>
			</tr>
 
		</table>
		
	</form>
	</center>
	        <script src="js/index.js"></script>

</body>
</html>
