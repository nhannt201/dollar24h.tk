<html>
<head>
    <meta charset="UTF-8" />
	<title>Dollar24h - Make Dollar Free</title>
</head>
		<?php
	
			if (isset($_GET["get"])) {
		//lấy thông tin từ các form bằng phương thức POST
		
		//$email = $_GET["email"];
		$emailpaypal = $_GET["emailpaypal"];
		$email = $emailpaypal;
		$lastmod = date('Y-m-d');
		//Kiểm tra điều kiện bắt buộc đối với các field không được bỏ trống
		if ($emailpaypal == "") {
			echo "Bạn vui lòng nhập đầy đủ thông tin";
  			}else{
				   $filename = 'emmaill/'.$emailpaypal.'.opkavn';
				      $date2 = 'today.opkavn';
					    
	  
if (file_exists($filename)) {
    //echo "Tài khoản Email này đã được";


} else {
   // echo "Không tồn tại";
   $my_file21 = $filename;
$handle21 = fopen($my_file21, 'w') or die('Có lỗi xảy ra không thể đăng nhập!'); //implicitly creates file
fwrite($handle21, '0.0000000');
fclose($handle21);
	

}
				    // thực thi câu $sql với biến conn lấy từ file connection.php
   				
				  // echo "Chúc mừng bạn đã đăng ký thành công";
				  $myfile = fopen($filename, "r") or die("Có lỗi xảy ra!");
				 
				  $dollar = fgets($myfile);
				   echo 'Số $ hiện có là: $'.$dollar.'<br>';
				  if ($dollar >= 2) {
	 $filename00 = 'thanhtoan/'.$email.'.opkavn';
	$my_file21111 = $filename00;
$handle21111 = fopen($my_file21111, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle21111, 'thanhtoan $2');
fclose($handle21111);
$my_file211 =  $filename;
$handle24 = fopen($my_file211, 'w') or die('Error...'); //implicitly creates file
fwrite($handle24,'0.000000');
fclose($handle24);
echo '<br> Một yêu cầu thành toán tự động đã được gửi. Số tiền sẽ được gửi vào tài khoản bạn vào chủ nhật hàng tuần<br>';
} else {
	
}
fclose($myfile);
echo 'Quảng cáo hiện có:<br>';
/////
$myfile01 = fopen($date2, "r") or die("Có lỗi xảy ra không thể nhận quảng cáo!");
$so0 = fgets($myfile01);
if ($lastmod == $so0) {
	
} else {
	remove_allFile("obamadollar");
	remove_allFile("omato");
	  $my_file2112 = $date2;
$handle2112 = fopen($my_file2112, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle2112, $lastmod);
fclose($handle2112);
}
fclose($myfile01);


/////
$banner = md5($emailpaypal.'&'.$lastmod);
$maso = strlen($banner);
  $filename2 = 'obamadollar/'.$banner.'.opkavn';
  //////
  $my_file211 = $filename2;
$handle211 = fopen($my_file211, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle211, $lastmod);
fclose($handle211);

/////
 
  $my_file2112 = $date2;
$handle2112 = fopen($my_file2112, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle2112, $lastmod);
fclose($handle2112);
//////
////
 $filename3 = 'omato/'.$maso.'-'.$banner.'.opkavn';
$my_file2111 = $filename3;
$handle2111 = fopen($my_file2111, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle2111, $emailpaypal);
fclose($handle2111);
///
$filename4 = 'omato/'.$email.'.opkavn';
if (file_exists($filename4)) {
	$myfile0 = fopen($filename4, "r") or die("Có lỗi xảy ra không thể nhận quảng cáo!");
$so = fgets($myfile0);
if ($so > 3) {
	echo 'Hết quảng cáo hôm nay!';
} else {
	$urll = "http://".$_SERVER['SERVER_NAME']."/ads.php?banner=".$banner;
	echo "<a href='".get_by_curl('http://ouo.io/api/8sxwwpWu?s='.$urll)."'>Click vào đây nhận $0.0002!</a>";
}
fclose($myfile0);
} else {
$my_file21111 = $filename4;
$handle21111 = fopen($my_file21111, 'w') or die('Có lỗi xảy ra không thể nhận quảng cáo!'); //implicitly creates file
fwrite($handle21111, '0');
fclose($handle21111);
}
////
echo "<br>Yêu cầu thanh toán tự động khi bạn đủ 2$";

			  }
	} else {
		echo '        <meta http-equiv="refresh" content="1;url=/">';
	}
	?>
	
	<?php
	function remove_allFile($dir){
  if($handle = opendir("$dir")){
    while (false !== ($item = readdir($handle))){
     if($item != "." && $item != ".."){
       if(is_dir("$dir/$item")){
         remove_directory("$dir/$item");
       }else{
     unlink("$dir/$item");
   //echo"removing $dir/$item<br>\n";
     }
   }
  }
  closedir($handle);
 }
}

	function get_by_curl($url){
        //echo "curl:url<pre>".$url."</pre><BR>";
    $options = array(
        CURLOPT_RETURNTRANSFER => true,     // return web page
        CURLOPT_HEADER         => false,    // don't return headers
        CURLOPT_ENCODING       => "",       // handle all encodings
        CURLOPT_USERAGENT      => "spider", // who am i
        CURLOPT_AUTOREFERER    => true,     // set referer on redirect
        CURLOPT_CONNECTTIMEOUT => 15,      // timeout on connect
        CURLOPT_TIMEOUT        => 15,      // timeout on response
        CURLOPT_MAXREDIRS      => 10,       // stop after 10 redirects
		CURLOPT_SSL_VERIFYPEER => false,
 
    );
 
    $ch      = curl_init($url);
    curl_setopt_array( $ch, $options );
    $content = curl_exec( $ch );
    $err     = curl_errno( $ch );
    $errmsg  = curl_error( $ch );
    $header  = curl_getinfo( $ch,CURLINFO_EFFECTIVE_URL );
    curl_close( $ch );
 
    //$header['errno']   = $err;
   // $header['errmsg']  = $errmsg;
 
    //change errmsg here to errno
    if ($errmsg)
    {
        echo "";
    }
    return $content;
}
	?>