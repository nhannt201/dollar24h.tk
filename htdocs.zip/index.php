<html>
<head>
    <meta charset="UTF-8" />
	<title>Dollar24h - Make Dollar Free</title>
</head>
<body>
	<form action="home.php" method="get">
		<table>
			<tr>
				<td colspan="2">Sẵng sàng nhận $?</td>
			</tr>	
			
			
			
			<tr>
				<td>Email PayPal:</td>
				<td><input type="email" id="emailpaypal" name="emailpaypal"></td>
			</tr>
			<tr>
				<td colspan="2" align="center"><input type="submit" name="get" value="GetDollar!"></td>
			</tr>
 
		</table>
		
	</form>
</body>
</html>
